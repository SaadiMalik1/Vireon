# Copyright 2026 VIREON Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import ast
from pathlib import Path

def get_imports(file_path: Path):
    with open(file_path, "r", encoding="utf-8") as f:
        try:
            tree = ast.parse(f.read(), filename=str(file_path))
        except SyntaxError:
            return set()

    imports = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for name in node.names:
                imports.add(name.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.add(node.module)
    return imports

def get_python_files(directory: str):
    return list(Path(directory).rglob("*.py"))

def test_sdk_does_not_import_core_or_lab():
    """The SDK is the lowest level. It cannot depend on the runtime or the lab."""
    sdk_files = get_python_files("vireon/sdk")
    for file in sdk_files:
        imports = get_imports(file)
        for imp in imports:
            assert not imp.startswith("vireon.runtime"), f"{file} illegally imports {imp}"
            assert not imp.startswith("vireon_lab"), f"{file} illegally imports {imp}"

def test_core_does_not_import_lab():
    """The core runtime framework cannot depend on educational code or scenarios."""
    core_files = get_python_files("vireon/core")
    for file in core_files:
        imports = get_imports(file)
        for imp in imports:
            assert not imp.startswith("vireon_lab"), f"{file} illegally imports {imp}"

def test_lab_providers_only_import_sdk():
    """
    Lab providers are plugins. Plugins must ONLY import from vireon.sdk,
    not from vireon.runtime (which leaks runtime internals).
    """
    provider_files = get_python_files("vireon_lab/providers")
    for file in provider_files:
        imports = get_imports(file)
        for imp in imports:
            # We enforce that providers don't reach into core.
            assert not imp.startswith("vireon.runtime"), f"Boundary Violation: Provider {file} illegally imports runtime module {imp}. It must use vireon.sdk instead."
