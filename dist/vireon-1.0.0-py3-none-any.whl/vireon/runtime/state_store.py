# Copyright 2026 VIREON Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import threading
from typing import Any, Dict
from vireon.sdk.events import IEventBus, Event
from vireon.sdk.state import IStateStore

class StateStore(IStateStore):
    """
    Central, thread-safe Key-Value store replacing the DigitalTwin God-class.
    All state mutations are broadcast over the EventBus.
    """
    def __init__(self, event_bus: IEventBus):
        self._state: Dict[str, Any] = {}
        self._lock = threading.RLock()
        self.event_bus = event_bus

    def get(self, key: str, default: Any = None) -> Any:
        with self._lock:
            return self._state.get(key, default)

    def set(self, key: str, value: Any, source: str = "system") -> None:
        with self._lock:
            old_value = self._state.get(key)
            if old_value != value:
                self._state[key] = value
                self.event_bus.publish(Event(
                    topic=f"state.changed.{key}",
                    data={"old": old_value, "new": value},
                    source=source
                ))

    def get_all(self) -> Dict[str, Any]:
        with self._lock:
            return dict(self._state)
