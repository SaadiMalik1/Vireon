# Copyright 2026 VIREON Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
from typing import List, Optional
from vireon.sdk.state import IStateStore

from .base import ISignalModifier

class NeuroPhishingAttack(ISignalModifier):
    """
    Simulates Cognitive Warfare / Neuro-Phishing.
    Adversarial injection of specific neural patterns (e.g. SSVEP or P300-like triggers)
    to manipulate the user's emotional state or BCI cursor control.
    """
    def __init__(self, target_channels: List[int], manipulation_type: str = "emotional"):
        self.target_channels = target_channels
        self.manipulation_type = manipulation_type
        self.time_counter = 0.0

    def apply(self, data: np.ndarray, eeg_channels: List[int], sample_rate: int, state_store: IStateStore, rng: Optional[np.random.Generator] = None) -> np.ndarray:
        mutated_data = data.copy()
        num_samples = data.shape[1]
        
        # Inject an Alpha-band (10 Hz) driving frequency for emotional manipulation
        # or a 15 Hz SSVEP pattern for BCI control hijacking.
        freq = 10.0 if self.manipulation_type == "emotional" else 15.0
        
        t = self.time_counter + np.arange(num_samples) / sample_rate
        trigger_wave = 25.0 * np.sin(2 * np.pi * freq * t)
        self.time_counter += num_samples / sample_rate
        
        for ch in self.target_channels:
            if ch in eeg_channels:
                mutated_data[ch, :] += trigger_wave
                
        # Register the cognitive manipulation in the Digital Twin
        state_store.set("clinical_alert_active", True, "ips")
        state_store.set("clinical_alert_msg", f"Neuro-Phishing: {self.manipulation_type.upper()} manipulation detected", "ips")
        if self.manipulation_type == "emotional":
            state_store.set("dsm5_diagnosis", "INDUCED_MANIA", "ips")
            state_store.set("diagnostic_cluster", "COGNITIVE_WARFARE", "ips")
            
        return mutated_data


class FirmwareRollbackAttack(ISignalModifier):
    """
    Simulates an Over-The-Air (OTA) Downgrade / Rollback Attack.
    Attempts to push a malicious firmware payload containing an older
    Security Version Number (SVN) to bypass anti-rollback protections.
    This attack doesn't mutate the signal window, but triggers the
    OTA process on the target twin/firmware.
    """
    def __init__(self, target_channels: List[int], payload_version: int = 0):
        self.target_channels = target_channels
        self.payload_version = payload_version
        self.has_fired = False

    @property
    def full_payload(self) -> bytes:
        import struct
        malicious_binary = b'A' * 600000
        header = struct.pack('<I', self.payload_version)
        dummy_signature = b'\x00' * 64
        return header + dummy_signature + malicious_binary

    def apply(self, data: np.ndarray, eeg_channels: List[int], sample_rate: int, state_store: IStateStore, rng: Optional[np.random.Generator] = None) -> np.ndarray:
        if not self.has_fired:
            # Construct a malicious payload: [Version header (4 bytes)] + [Overflow Payload]
            # Version is lower than the expected minimum (e.g., SVN 0)
            
            # Record the attempt on the Digital Twin's event log or directly via the firmware
            state_store.set("clinical_alert_active", True, "ips")
            state_store.set("clinical_alert_msg",  f"Malicious OTA Downgrade Attempted (SVN {self.payload_version})")
            
            # The actual OTA simulation happens in the Coordinator by invoking the firmware stub.
            # Here we just mark that the attack window triggered.
            self.has_fired = True
            
        return data

    def revert(self, state_store: IStateStore) -> None:
        """Clear the clinical alert if it was triggered."""
        if self.has_fired:
            state_store.set("clinical_alert_active", False)
            state_store.set("clinical_alert_msg",  "Nominal")


class InsiderThreatAttack(ISignalModifier):
    """
    Simulates an insider threat where a compromised clinician sets dangerous
    stimulation parameters directly, bypassing normal safeguards.
    """
    def __init__(self, target_channels: List[int]):
        self.target_channels = target_channels
        self.has_fired = False

    def apply(self, data: np.ndarray, eeg_channels: List[int], sample_rate: int, state_store: IStateStore, rng: Optional[np.random.Generator] = None) -> np.ndarray:
        if not self.has_fired:
            print("[InsiderThreatAttack] Injecting malicious clinical configuration...")
            # Force a dangerous parameter directly on the twin
            if hasattr(state_store, "_lock"):
                with state_store._lock:
                    state_store.set("stimulation_amplitude_ma", 15.0, "ips")
                    state_store.set("clinical_alert_active", True, "ips")
                    state_store.set("clinical_alert_msg", "Insider Threat: Dangerous parameters injected", "ips")
            else:
                state_store.set("stimulation_amplitude_ma", 15.0, "ips")
                state_store.set("clinical_alert_active", True, "ips")
                state_store.set("clinical_alert_msg", "Insider Threat: Dangerous parameters injected", "ips")
            self.has_fired = True
        return data

    def revert(self, state_store: IStateStore) -> None:
        if self.has_fired:
            if hasattr(state_store, "_lock"):
                with state_store._lock:
                    state_store.set("stimulation_amplitude_ma", 5.0, "ips")
                    state_store.set("clinical_alert_active", False, "ips")
                    state_store.set("clinical_alert_msg", "Nominal", "ips")
            else:
                state_store.set("stimulation_amplitude_ma", 5.0, "ips")
                state_store.set("clinical_alert_active", False, "ips")
                state_store.set("clinical_alert_msg", "Nominal", "ips")
            self.has_fired = False
