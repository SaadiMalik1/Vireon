# Copyright 2026 VIREON Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from dataclasses import dataclass, field
from typing import List

@dataclass
class CapabilityManifest:
    name: str
    version: str
    category: str
    publishes_events: List[str] = field(default_factory=list)
    subscribes_events: List[str] = field(default_factory=list)
    mutates_state: List[str] = field(default_factory=list)
    reads_state: List[str] = field(default_factory=list)
    requires_host_access: bool = False
